PImage planeImg;
PImage sky2Img;
PImage bombImg;

float planeX, planeY;
float planeSpeed = 7; 

float[] bombX = new float[10];
float[] bombY = new float[10];
float[] bombSpeed = new float[10];

int score = 0;
boolean gameOver = false;

void setup() {
  size(650, 500);
  
  planeImg = loadImage("OIP.png");
  planeImg.resize(70, 70);
  
  sky2Img = loadImage("sky2.png");
  sky2Img.resize(width, height);
  
  bombImg = loadImage("bomb.png");
  bombImg.resize(50,50);
  
  
  
   Game();
}

void Game() {
  planeX = width/2;
  planeY = height - 70;
  score = 0;
  gameOver = false;
  
  for (int i = 0; i < bombX.length; i++) {
    collectBomb(i);
  }
}

void draw() {
  if (!gameOver) {
    background(sky2Img);
    
    
    fill(0);
    textSize(22);
    textAlign(LEFT);
    text("Score: " + score, 20, 35);

    drawPlane();
    movePlane();
    drawBombs();
    
  } else {
    showGameOver();
  }
}

void drawPlane() {
  imageMode(CENTER);
  image(planeImg, planeX, planeY);
}

void movePlane() {
  if (keyPressed) {
    if (keyCode == LEFT ) planeX -= planeSpeed;
    if (keyCode == RIGHT) planeX += planeSpeed;
   
  }
  
  planeX = constrain(planeX, 25, width-25);
  planeY = constrain(planeY, 25, height-25);
}
             
void drawBombs() {
  for (int i = 0; i < bombX.length; i++) {
  
    imageMode(CENTER);
    image(bombImg,bombX[i], bombY[i], 40, 40);
    bombY[i] += bombSpeed[i];

    
    if (dist(planeX, planeY, bombX[i], bombY[i]) < 35) {
      gameOver = true;
    }

   
    if (bombY[i] > height) {
      collectBomb(i);
      score++; 
    }
  }
}

void collectBomb(int i) {
  bombX[i] = random(20, width-20);
  bombY[i] = random(-600, -50);
  bombSpeed[i] = random(5, 9); 
}

void showGameOver() {
  background(sky2Img); 
  fill(0);
  textAlign(CENTER);
  textSize(45);
  text("GAME OVER!", width/2, height/2 - 20);
  text("TRY AGAIN..!!",width/2, height/2 +35);
  
  
  textSize(25);
  text("Final Score: " + score, width/2, height/2 + 80);
  fill(#C4020F); 
  text("Press ENTER to Restart", width/2, height/2 + 120);
  
  if (keyPressed && key == ENTER) {
    Game();
  }
}
